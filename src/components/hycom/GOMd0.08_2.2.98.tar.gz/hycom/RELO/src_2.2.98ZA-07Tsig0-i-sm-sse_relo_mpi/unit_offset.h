c
c --- uoff= offset for all unit numbers (in module mod_xc)
      integer    uoff
      parameter (uoff=2000)
